package com.seo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.seo.model.Board;
import com.seo.model.User;

public class UserDao {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public UserDao()
	{
		try
		{
			String dbURL="jdbc:mysql://localhost:3307/finaldb?characterEncoding=utf-8";
			String dbID="root";
			String dbPassword="rudrnrsla9@";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public int login(String userID, String userPassword)
	{
		String SQL="SELECT user_pass FROM finaldb.user where user_id=?";
		try
		{
			pstmt=conn.prepareStatement(SQL);
			pstmt.setString(1, userID);
			rs=pstmt.executeQuery();
			if(rs.next())
			{
				if(rs.getString(1).equals(userPassword))
				{
					return 1; // 로그인 성공
				}
				else
				{
					return 0; // 비밀번호 틀림
				}
			}
			return -1; // 아이디가 없음
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return -2; // 데이터베이스 오류
	}
	public int join(User user)
	{
		String SQL="INSERT INTO user VALUES(?, ?, ?, ?, ?, ?)";
		try
		{
			pstmt=conn.prepareStatement(SQL);
			pstmt.setString(1, user.getUser_name());
			pstmt.setString(2, user.getUser_email());
			pstmt.setString(3, user.getUser_phone());
			pstmt.setString(4, user.getUser_id());
			pstmt.setString(5, user.getUser_pass());
			pstmt.setInt(6, 0);
			return pstmt.executeUpdate();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return -1;
	}
	public User getUser(String user_id)
	{
		String SQL = "SELECT * FROM finaldb.user"
				+ " where user_id = ?";
		try
		{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, user_id);
			rs=pstmt.executeQuery();
			if(rs.next())
			{
				User user = new User();
				user.setUser_name(rs.getString(1));
				user.setUser_email(rs.getString(2));
				user.setUser_phone(rs.getString(3));
				user.setUser_id(rs.getString(4));
				user.setUser_pass(rs.getString(5));
				user.setUser_access(rs.getInt(6));
				
				return user;
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	public ArrayList<User> getList()
	{
		String SQL = "SELECT * FROM user";
		ArrayList<User> list = new ArrayList<User>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			while(rs.next())
			{
				User user = new User();
				user.setUser_name(rs.getString(1));
				user.setUser_email(rs.getString(2));
				user.setUser_phone(rs.getString(3));
				user.setUser_id(rs.getString(4));
				user.setUser_pass(rs.getString(5));
				user.setUser_access(rs.getInt(6));
				list.add(user);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}
	public int updateUser(String RuserID, String userName, String userPassword, String userPhonenum)
	{
		String SQL = "UPDATE finaldb.user SET user_name = ?, user_pass = ?, user_phone = ?"
				+ " WHERE user_id = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1,userName);
			pstmt.setString(2,userPassword);
			pstmt.setString(3,userPhonenum);
			pstmt.setString(4,RuserID);
			
			return pstmt.executeUpdate();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return -1;
	}
	public int delete(String userID)
	{
		String SQL2 = "DELETE FROM finaldb.user WHERE user_id = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL2);
			pstmt.setString(1,userID);
			return pstmt.executeUpdate();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return -1;
	}
}
