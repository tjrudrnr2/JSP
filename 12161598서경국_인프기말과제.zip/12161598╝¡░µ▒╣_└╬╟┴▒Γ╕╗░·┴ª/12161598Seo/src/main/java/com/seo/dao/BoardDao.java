package com.seo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.seo.model.Board;
import com.seo.model.User;

public class BoardDao {
	private Connection conn;
	private ResultSet rs;
	
	public BoardDao()
	{
		try
		{
			String dbURL="jdbc:mysql://localhost:3307/finaldb?characterEncoding=utf-8";
			String dbID="root";
			String dbPassword="rudrnrsla9@";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public String getDate()
	{
		String SQL = "SELECT NOW()";
		try
		{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next())
			{
				return rs.getString(1);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return ""; // 데이터베이스 오류
	}
	public int getNext()
	{
		String SQL = "SELECT board_num FROM Board order by board_num DESC";
		try
		{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next())
			{
				return rs.getInt(1)+1;
			}
			return 1; // 첫 번째 게시물
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return -1; // 데이터베이스 오류
	}
	public int write(String boardcase, String userID, String title, 
			String content, String url, int pub)
	{
		String SQL = "INSERT INTO finaldb.board VALUES (?,?,?,?,?,?,?,?,?)";
		try
		{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, boardcase);
			pstmt.setString(3, userID);
			pstmt.setString(4, title);
			pstmt.setString(5, content);
			pstmt.setString(6, url);
			pstmt.setString(7, getDate());
			pstmt.setInt(8, pub);
			pstmt.setInt(9, 1);
			
			return pstmt.executeUpdate(); // 첫 번째 게시물
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return -1; // 데이터베이스 오류
	}
	public ArrayList<Board> getList(int pageNumber)
	{
		String SQL = "SELECT * FROM board where board_state = 1 and board_num < ? "
				+ "order by board_num desc limit 10";
		ArrayList<Board> list = new ArrayList<Board>();
		try
		{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				Board board = new Board();
				board.setBoard_num(rs.getInt(1));
				board.setBoard_case(rs.getString(2));
				board.setBoard_writer(rs.getString(3));
				board.setBoard_title(rs.getString(4));
				board.setBoard_content(rs.getString(5));
				board.setBoard_url(rs.getString(6));
				board.setBoard_time(rs.getString(7));
				board.setBoard_public(rs.getInt(8));
				board.setBoard_state(rs.getInt(9));
				list.add(board);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}
	public boolean nextPage(int pageNumber)
	{
		String SQL = "SELECT * FROM finaldb.board where board_state = 1 and board_num < ? order by board_num"
				+ " desc limit 10";
		try
		{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs=pstmt.executeQuery();
			if(rs.next())
			{
				return true;
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
	public Board getBoard(int board_num)
	{
		String SQL = "SELECT * FROM finaldb.board where board_num = ?";
		try
		{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, board_num);
			rs=pstmt.executeQuery();
			if(rs.next())
			{
				Board board = new Board();
				board.setBoard_num(rs.getInt(1));
				board.setBoard_case(rs.getString(2));
				board.setBoard_writer(rs.getString(3));
				board.setBoard_title(rs.getString(4));
				board.setBoard_content(rs.getString(5));
				board.setBoard_url(rs.getString(6));
				board.setBoard_time(rs.getString(7));
				board.setBoard_public(rs.getInt(8));
				board.setBoard_state(rs.getInt(9));
				
				return board;
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public int update(int board_num, String board_title, String board_content)
	{
		String SQL = "UPDATE finaldb.board SET board_title=?, board_content=? where board_num=?";
		try
		{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, board_title);
			pstmt.setString(2, board_content);
			pstmt.setInt(3, board_num);
			
			return pstmt.executeUpdate();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return -1; // 데이터베이스 오류
	}
	public int delete(int board_num)
	{
		String SQL = "UPDATE finaldb.board SET board_state=0 where board_num=?";
		try
		{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, board_num);
			
			return pstmt.executeUpdate();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return -1; // 데이터베이스 오류
	}
}
