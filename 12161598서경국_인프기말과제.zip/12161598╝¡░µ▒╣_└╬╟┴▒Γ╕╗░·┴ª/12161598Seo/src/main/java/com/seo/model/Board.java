package com.seo.model;

public class Board {
	private int board_num;
	private String board_case;
	private String board_writer;
	private String board_title;
	private String board_content;
	private String board_url;
	private String board_time;
	private int board_public;
	private int board_state;
	
	public int getBoard_num() {
		return board_num;
	}
	public void setBoard_num(int board_num) {
		this.board_num = board_num;
	}
	public String getBoard_case() {
		return board_case;
	}
	public void setBoard_case(String board_case) {
		this.board_case = board_case;
	}
	public String getBoard_writer() {
		return board_writer;
	}
	public void setBoard_writer(String board_writer) {
		this.board_writer = board_writer;
	}
	public String getBoard_title() {
		return board_title;
	}
	public void setBoard_title(String board_title) {
		this.board_title = board_title;
	}
	public String getBoard_content() {
		return board_content;
	}
	public void setBoard_content(String board_content) {
		this.board_content = board_content;
	}
	public String getBoard_url() {
		return board_url;
	}
	public void setBoard_url(String board_url) {
		this.board_url = board_url;
	}
	public String getBoard_time() {
		return board_time;
	}
	public void setBoard_time(String board_time) {
		this.board_time = board_time;
	}
	public int getBoard_public() {
		return board_public;
	}
	public void setBoard_public(int board_public) {
		this.board_public = board_public;
	}
	public int getBoard_state() {
		return board_state;
	}
	public void setBoard_state(int board_state) {
		this.board_state = board_state;
	}
}
